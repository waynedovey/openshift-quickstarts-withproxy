# openshift-quickstarts
Quickstarts used by templates in github.com/jboss-openshift/application-templates
